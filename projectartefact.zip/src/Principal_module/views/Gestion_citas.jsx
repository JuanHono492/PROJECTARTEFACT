import React, { useState, useEffect } from 'react';
import axios from 'axios';

const GestionCitas = () => {
    const [doctors, setDoctors] = useState([]);
    const [patients, setPatients] = useState([]);
    const [selectedPatient, setSelectedPatient] = useState(null);
    const [citaData, setCitaData] = useState({
        doctorID: '',
        fechaCita: '',
        horaCita: '',
        motivoCita: '',
        numeroHistoriaClinica: ''
    });

    useEffect(() => {
        // Fetch doctors
        axios.get('/citas/doctors').then(response => setDoctors(response.data));

        // Fetch patients (optional: only load when needed)
    }, []);

    const handlePatientSearch = (dni) => {
        axios.post('/citas/patients', { dni })
            .then(response => setSelectedPatient(response.data))
            .catch(error => console.error("Error finding patient:", error));
    };

    const handleCitaSubmit = () => {
        axios.post('/citas', { ...citaData, pacienteID: selectedPatient?.PacienteID })
            .then(response => alert("Cita creada exitosamente"))
            .catch(error => console.error("Error creating appointment:", error));
    };

    return (
        <div>
            <h1>Gestión de Citas</h1>
            <div>
                <h2>Nueva Cita</h2>
                <input
                    type="text"
                    placeholder="Buscar Paciente por DNI"
                    onBlur={(e) => handlePatientSearch(e.target.value)}
                />
                {selectedPatient && (
                    <div>
                        <p>{selectedPatient.Nombre} {selectedPatient.Apellido}</p>
                        <p>Numero de Historia: {selectedPatient.NumeroHistoriaClinica}</p>
                    </div>
                )}
                <select
                    value={citaData.doctorID}
                    onChange={(e) => setCitaData({ ...citaData, doctorID: e.target.value })}
                >
                    <option value="">Seleccione Doctor</option>
                    {doctors.map(doc => (
                        <option key={doc.DoctorID} value={doc.DoctorID}>{doc.Nombre}</option>
                    ))}
                </select>
                <input
                    type="date"
                    value={citaData.fechaCita}
                    onChange={(e) => setCitaData({ ...citaData, fechaCita: e.target.value })}
                />
                <input
                    type="time"
                    value={citaData.horaCita}
                    onChange={(e) => setCitaData({ ...citaData, horaCita: e.target.value })}
                />
                <input
                    type="text"
                    placeholder="Motivo de la Cita"
                    value={citaData.motivoCita}
                    onChange={(e) => setCitaData({ ...citaData, motivoCita: e.target.value })}
                />
                <button onClick={handleCitaSubmit}>Agregar Cita</button>
            </div>
        </div>
    );
};

export default GestionCitas;
