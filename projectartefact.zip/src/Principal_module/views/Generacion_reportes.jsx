import React from 'react';
import NavigationBar from '../components/navegation_bar';

const Generación_reportes = () => {
    return (
        <div className="dashboard-container">
            <nav className="navbar">
                <NavigationBar /> 
            </nav>
            <main className="main-content">
                <h1>Generacion de reportes</h1>
                <p>En proceso...</p>
            </main>
        </div>
    );
};

export default Generación_reportes;
