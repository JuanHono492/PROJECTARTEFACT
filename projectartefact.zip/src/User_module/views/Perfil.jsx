import React from 'react';

const Perfil = () => {
    return (
        <div>
            <h1>tu perfil pe</h1>
            <p>Aquí puedes gestionar las citas de los pacientes.</p>
        </div>
    );
};

export default Perfil;
